var restFile = {
    "rest": [
        {"name": "한식1"}, //한식1
        {"name": "한식2"},
        {"name": "한식3"},
        {"name": "한식4"},
        {"name": "한식5"},
        {"name": "한식6"},
        {"name": "한식7"},
        {"name": "한식8"},
        {"name": "한식9"}, //한식9
        {"name": "중식1"}, //중식1
        {"name": "중식2"},
        {"name": "중식3"},
        {"name": "중식4"},
        {"name": "중식5"},
        {"name": "에에에엥"},
        {"name": "중식7"},
        {"name": "중식8"},
        {"name": "중식9"}, //중식9
        {"name": "일식1"}, //일식1
        {"name": "일식2"},
        {"name": "일식3"},
        {"name": "일식4"},
        {"name": "일식5"},
        {"name": "일식6"},
        {"name": "일식7"},
        {"name": "일식8"},
        {"name": "일식9"}, //일식9
        {"name": "양식1"}, //양식1
        {"name": "양식2"},
        {"name": "양식3"},
        {"name": "양식4"},
        {"name": "양식5"},
        {"name": "양식6"},
        {"name": "양식7"},
        {"name": "양식8"},
        {"name": "양식9"}, //양식9
        {"name": "기타1"}, //기타1
        {"name": "기타2"},
        {"name": "기타3"},
        {"name": "기타4"},
        {"name": "기타5"},
        {"name": "기타6"},
        {"name": "기타7"},
        {"name": "기타8"},
        {"name": "기타9"}, //기타9
    ]
};
        restFile.rest.forEach((restaurant, index) => {
            let category;
            if (index < 9) {
                category = '한식';
            } else if (index < 18) {
                category = '중식';
            } else if (index < 27) {
                category = '일식';
            } else if (index < 36) {
                category = '양식';
            } else {
                category = '기타';
            }

            window[`${category}${(index % 9) + 1}`] = restaurant.name;
        });
